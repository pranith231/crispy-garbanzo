package com.clipforge.editor

import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.util.Locale
import kotlin.math.max

private val Canvas = Color(0xFF101114)
private val Panel = Color(0xFF1B1D23)
private val Accent = Color(0xFF9B8CFF)
private val Muted = Color(0xFF9A9DA8)

class MainActivity : ComponentActivity() {
    @androidx.media3.common.util.UnstableApi
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClipForgeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun ClipForgeApp() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(0L) }
    var exporting by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Import a video to start editing") }
    var outputPath by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            videoUri = uri
            durationMs = 0L
            startMs = 0L
            endMs = 0L
            status = "Video loaded. Preparing preview…"
        }
    }

    val player = remember(videoUri) {
        videoUri?.let {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(it))
                prepare()
                playWhenReady = false
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY) {
                            val d = duration.coerceAtLeast(0L)
                            durationMs = d
                            if (endMs == 0L || endMs > d) endMs = d
                            status = "Ready to edit"
                        }
                    }
                })
            }
        }
    }
    DisposableEffect(player) { onDispose { player?.release() } }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Canvas, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Canvas, topBar = {
            TopAppBar(
                title = { Column { Text("CLIPFORGE", fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("Offline video studio", color = Muted, fontSize = 11.sp) } },
                actions = { Text("BETA", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 18.dp)) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Canvas)
            )
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                        Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(8.dp)); Text("Import video")
                    }
                    OutlinedButton(onClick = { player?.seekTo(0) }, enabled = player != null) { Icon(Icons.Default.Replay, null); Text(" Reset") }
                }

                Box(Modifier.fillMaxWidth().height(210.dp).background(Color.Black, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                    if (player != null) {
                        AndroidView(factory = { ctx ->
                            androidx.media3.ui.PlayerView(ctx).apply {
                                this.player = player
                                useController = true
                                setShowBuffering(androidx.media3.ui.PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                            }
                        }, update = { it.player = player }, modifier = Modifier.fillMaxSize())
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Movie, null, tint = Muted, modifier = Modifier.size(42.dp))
                            Spacer(Modifier.height(8.dp)); Text("Your preview appears here", color = Muted)
                        }
                    }
                }

                SectionTitle("01  ·  SMART TRIM")
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Choose the part you want to keep", color = Muted, fontSize = 13.sp)
                        Text("Start  ${timeLabel(startMs)}", fontWeight = FontWeight.SemiBold)
                        Slider(value = startMs.toFloat(), onValueChange = { startMs = it.toLong().coerceAtMost(max(0L, endMs - 500L)) }, valueRange = 0f..max(1L, durationMs).toFloat(), enabled = durationMs > 0)
                        Text("End  ${timeLabel(endMs)}", fontWeight = FontWeight.SemiBold)
                        Slider(value = endMs.toFloat(), onValueChange = { endMs = it.toLong().coerceAtLeast(startMs + 500L).coerceAtMost(durationMs) }, valueRange = 0f..max(1L, durationMs).toFloat(), enabled = durationMs > 0)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Source: ${timeLabel(durationMs)}", color = Muted, fontSize = 12.sp)
                            Text("Selected: ${timeLabel((endMs - startMs).coerceAtLeast(0))}", color = Accent, fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = {
                            val p = player
                            if (p != null) p.seekTo(startMs)
                        }, enabled = player != null, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.GpsFixed, null); Text(" Preview trim start") }
                    }
                }

                SectionTitle("02  ·  OFFLINE ASSISTANT")
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AutoAwesome, tint = Accent, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Quick edit suggestion", fontWeight = FontWeight.Bold) }
                        Text(if (durationMs > 0) "Your clip is ${timeLabel(durationMs)} long. For a short social edit, choose the strongest moment and keep the final cut around 15–30 seconds." else "Import a clip and the assistant will suggest a simple edit workflow.", color = Muted, fontSize = 13.sp)
                        Text("This first version uses on-device editing rules, not cloud AI. Your footage stays on your phone.", color = Muted, fontSize = 11.sp)
                        OutlinedButton(onClick = {
                            if (durationMs > 0) {
                                startMs = 0L
                                endMs = minOf(durationMs, 30_000L)
                                status = "Suggested a ${timeLabel(endMs)} opening cut. Adjust it before export."
                            }
                        }, enabled = durationMs > 0, modifier = Modifier.fillMaxWidth()) { Text("Suggest a 30-second cut") }
                    }
                }

                SectionTitle("03  ·  EXPORT")
                Button(onClick = {
                    val uri = videoUri
                    if (uri == null || durationMs <= 0L) {
                        Toast.makeText(context, "Import a video first", Toast.LENGTH_SHORT).show()
                    } else if (endMs <= startMs || endMs - startMs < 500L) {
                        Toast.makeText(context, "Choose a valid trim range", Toast.LENGTH_SHORT).show()
                    } else {
                        exporting = true
                        status = "Exporting… keep ClipForge open"
                        val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
                        val out = File(dir, "ClipForge_${System.currentTimeMillis()}.mp4")
                        val clipped = MediaItem.Builder().setUri(uri).setClippingConfiguration(
                            MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(startMs)
                                .setEndPositionMs(endMs)
                                .build()
                        ).build()
                        val edited = EditedMediaItem.Builder(clipped).build()
                        val transformer = Transformer.Builder(context).addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                                exporting = false
                                outputPath = out.absolutePath
                                status = "Export complete"
                                Toast.makeText(context, "Saved in Android/data/com.clipforge.editor/files/Movies", Toast.LENGTH_LONG).show()
                            }
                            override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                                exporting = false
                                status = "Export failed: ${exportException.errorCodeName}"
                                Toast.makeText(context, status, Toast.LENGTH_LONG).show()
                            }
                        }).build()
                        try { transformer.start(edited, out.absolutePath) } catch (e: Exception) {
                            exporting = false
                            status = "Could not start export: ${e.message ?: "unknown error"}"
                        }
                    }
                }, enabled = videoUri != null && !exporting, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(14.dp)) {
                    if (exporting) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White); Spacer(Modifier.width(10.dp)); Text("Exporting…") }
                    else { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("Export trimmed MP4") }
                }
                Text(status, color = Muted, fontSize = 12.sp)
                outputPath?.let { Text("Output: $it", color = Accent, fontSize = 11.sp) }
                Text("ClipForge 1.0 · Local processing · No account · No cloud upload", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 8.dp))
            }
        }
    }
}

@Composable private fun SectionTitle(text: String) {
    Text(text, color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
}

private fun timeLabel(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L)
    return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
}
