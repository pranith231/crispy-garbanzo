# ClipForge — lightweight offline Android video editor

A native Kotlin + Jetpack Compose starter app focused on low-end Android devices.

## Included in this MVP
- Open a local video through Android's Storage Access Framework (no broad storage permission).
- Preview the selected video with Media3 ExoPlayer.
- Select a start/end range and preview the trim start.
- Export the selected range as an MP4 using AndroidX Media3 Transformer.
- A small offline rule-based editing assistant that suggests an opening 30-second cut.

## Important scope notes
This is an MVP, not a CapCut replacement. It currently does **not** include multi-track editing, split/merge timeline, music overlays, text layers, transitions, AI scene detection, or 1080p/720p quality selection. The current assistant is rule-based, not a trained generative AI model. Media3 Transformer chooses an output format based on the source and supported device codecs; this MVP does not promise a fixed output resolution.

## Build in Android Studio
1. Install the latest stable Android Studio with Android SDK Platform 35 and JDK 17.
2. Extract this project ZIP.
3. In Android Studio choose **Open** and select the `ClipForge` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync and dependency downloads.
5. Connect an Android phone with USB debugging enabled, or start an emulator.
6. Select **Run > Run 'app'** to install the debug build.
7. To create an APK, select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Export location
Exports are written to the app-specific Movies directory:
`Android/data/com.clipforge.editor/files/Movies`

Some file manager apps hide Android/data. Connect the phone to a computer or use a file manager that can access app-specific external storage to retrieve exports. Uninstalling the app may remove these files.

## Device targets
- Minimum Android: 8.0 (API 26)
- Compile/target SDK: 35
- Designed to avoid loading the full video into memory; playback and export are delegated to Media3 and device codecs.
- Large 4K files may still be slow or unsupported on entry-level hardware.

## Dependencies
- Kotlin 2.0.21
- Android Gradle Plugin 8.7.3
- Jetpack Compose BOM 2024.12.01
- AndroidX Media3 1.5.1

All editing in this MVP is local. No network permission is declared.
